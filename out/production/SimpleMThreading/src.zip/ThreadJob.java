public class ThreadJob extends Thread {

    @Override
    public void run() {
        //do something
    }


}